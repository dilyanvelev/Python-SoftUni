

class Caretaker(Worker):
    pass