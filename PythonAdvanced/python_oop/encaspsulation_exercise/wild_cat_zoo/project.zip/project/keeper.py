

class Keeper(Worker):
    pass