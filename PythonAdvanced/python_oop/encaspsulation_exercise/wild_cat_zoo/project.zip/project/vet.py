

class Vet(Worker):
    pass
